---
name: static-web-app
description: Build zero-build, zero-dependency static web apps (HTML + CSS + vanilla JS) that auto-discover data files sitting next to the page, support day/night theme switching, and deploy to IIS, nginx, or GitHub Pages. Use when the user asks to 做一个静态网页 / 本地静态工具 / 单页应用 / 本地播放器 / 相册 / 文档浏览页, mentions 白天夜间主题 or 主题切换, wants the page to 自动读取 music / images / data 文件夹, or plans to 部署到 IIS / 发布到 GitHub Pages / 双击 index.html 直接打开.
agent_created: true
---

# Static Web App

## 概述

一套用于构建**零构建、零依赖、可离线运行**的静态单页应用的工程方法：HTML + CSS + 原生 JS，数据文件（音乐、图片、文档、CSV…）与页面同目录存放，页面自己发现它们。产物可直接双击 `index.html` 打开，也可原样部署到 IIS / nginx / GitHub Pages。

本技能沉淀自一个完整交付的本地音乐播放器项目（双主题、歌词同步、歌单持久化、IIS 目录自动扫描），复用其结构决策与踩坑结论，可把同类项目从"从零摸索"压缩到一次成型。

## 何时使用

命中以下任意一条即应加载本技能：

- 要做网页但**不需要框架/打包**：本地工具、播放器、相册、阅读器、数据看板、单页小游戏外壳
- 要求**白天/夜间双主题**，且刷新后保持选择
- 要求页面**自动读取同目录下的资源文件夹**（`music/`、`images/`、`data/`…），而不是让用户手动一个个选文件
- 交付目标包含 **IIS / nginx / GitHub Pages** 部署，或"双击 index.html 就能用"
- 需要在离线、无后端、无数据库的前提下保存用户状态（收藏、歌单、设置）

不适用：需要服务端渲染、账号体系、实时协作、复杂状态管理的项目——那些应选框架 + 后端方案。

## 核心决策（先定这几条，再写代码）

1. **零构建、零外部依赖**。不用 npm、不用 CDN、不引第三方 UI 库，图标一律内联 SVG。理由：用户可能在内网 IIS 或断网环境打开，任何外部请求都是故障点。
2. **文件系统即数据库**。用户把文件拖进目录就算"入库"，不做上传、不做数据库。页面只负责发现和渲染。
3. **三级数据获取降级**，顺序固定：
   - ① `manifest.json`（服务端生成的清单，最可靠）
   - ② 抓取目录列表 HTML 解析（IIS / nginx / Apache 的目录浏览）
   - ③ 用户手动选择（`showDirectoryPicker` → `<input webkitdirectory>` → `<input multiple>` 三级降级）
   任一级成功即停；全部失败时**在页面上给出具体原因和解决步骤**，不要只弹一句"加载失败"。
4. **主题靠 CSS 变量 + `html[data-theme]`**。所有颜色只在两个主题块里定义，组件样式一律 `var(--x)`，禁止组件内写死颜色——否则浅色主题必然漏改。
5. **所有用户状态进 localStorage**，键名加项目前缀（`mw:theme`）。读档时逐字段校验并回退默认值，防止旧版本脏数据把页面打断。
6. **单页 + `hidden` 显隐切换**，不做路由。多视图切换不刷新，状态自然保留。

## 工作流

### 1. 明确三件事

开工前确认（缺信息就按最合理默认值先做，不要反复追问）：

- **数据是什么**：文件类型、目录名、是否需要与另一目录配对（如音频 ↔ 同名歌词）
- **状态是什么**：哪些东西要记住（主题、收藏、播放模式、上次位置）
- **在哪运行**：双击打开 / 本地服务器 / IIS / GitHub Pages —— 决定要不要做目录扫描降级

### 2. 搭骨架

复制 `assets/site-skeleton/` 作为起点，已包含：

- `index.html`：三栏布局 + 顶栏（搜索、主题开关）+ 列表容器 + 空状态
- `css/style.css`：双主题变量、布局骨架、滚动条、移动端断点
- `js/core.js`：**可直接复用的基础设施**（主题、localStorage、目录扫描、清单加载、字符串工具）
- `js/app.js`：业务逻辑占位，只需替换渲染与交互

目录约定（新项目照抄，便于直接使用 `scripts/`）：

```
project/
├── index.html
├── css/style.css
├── js/core.js        基础设施（几乎不改）
├── js/app.js         业务逻辑
├── music/ images/ data/      ← 用户放资源的地方，随项目附带 README.txt
├── tools/local_server.py    本地预览（支持 Range，媒体可拖动）
├── tools/make_manifest.py   生成 manifest.json
├── web.config               IIS 配置
├── README.md                使用与部署说明
└── start.bat                Windows 一键启动（可选）
```

### 3. 主题系统

读 `references/theme-system.md`，按顺序实现：

1. 在 `<head>` 中**内联**一小段脚本写入 `data-theme`（见 `assets/site-skeleton/index.html` 头部），必须在 CSS 生效前执行，否则浅色用户会先看到一帧黑底
2. `<html data-theme="dark">` 作为兜底默认值
3. 两个变量块：`html[data-theme="dark"]` 与 `html[data-theme="light"]`，变量名固定为 `--bg / --panel / --border / --text / --text-dim / --text-faint / --shadow / --input-bg`
4. 切换按钮：读 localStorage → 改 `documentElement.dataset.theme` → 写回；图标用两个 `<svg>` 靠 CSS 显隐
5. `<meta name="color-scheme" content="dark light">` 让原生控件（滚动条、表单）跟随主题

### 4. 数据发现

读 `references/data-discovery.md`。要点：

- 目录列表解析**不能依赖固定 HTML 结构**，只认 `a[href]`：能解析出条目即视为可读；`../` 链接和标题含 `Index of` 仅作辅助判断（Python `http.server` 的列表没有 `../`，早期版本因此误判失败）
- 中文文件名必须 `decodeURIComponent`，并 `try/catch` 兜底
- 递归深度限制 4 层，子目录读取失败静默跳过，不得中断整轮扫描
- 与另一目录配对时用**归一化键**：`lower` → 去空白 → 去 `_ - – — · . , 、 ' " “” () （） [ ]` → 去开头序号（`01.`、`1-`）
- 失败诊断分级：403 → 未开目录浏览；404 → 目录名不对；返回非列表 → 默认页或 SPA fallback。每种给一句可执行指引

### 5. 本地跑起来

```bash
python tools/local_server.py 8000    # 自动开浏览器，端口占用自动 +1
python tools/make_manifest.py        # 需要清单时
```

`local_server.py` 必须支持 **Range 请求**，否则音频/视频进度条无法拖动（表现为"点了没反应"）。`scripts/local_server.py` 已实现。

### 6. 浏览器实测（不可跳过）

静态页面"看起来对"和"实际能用"差距很大。每轮改动后执行：

```bash
NODE_PATH=<node-workspace>/node_modules node scripts/verify_page.js \
  --url http://127.0.0.1:8000/ \
  --expect "#list .item" --click "#list .item" --shot ./check.png
```

输出：命中元素数量、控制台报错、交互后状态、截图。未经真实浏览器验证的交付视为未完成。

浏览器命令行参数 `--dump-dom` / `--screenshot` 在部分环境返回空，**改用 `scripts/verify_page.js`（playwright-core + 系统 Edge，无需下载浏览器）**。

### 7. 部署产物

读 `references/deployment.md`：

- **IIS**：附带 `web.config`（启用目录浏览 + 补 flac/ogg/opus 等 MIME + defaultDocument）。若服务器未安装"目录浏览"角色功能，`<directoryBrowse>` 会触发 500.19 —— README 要同时给出"安装功能"和"删掉该节点改用 manifest"两条退路
- **GitHub Pages**：提交 `.nojekyll`（否则 `_` 开头的文件被忽略）；页面纯静态可直接推仓库；但 Pages **不支持目录列表**，必须提供 `manifest.json`（推送前跑一次 `make_manifest.py`）
- **nginx**：`autoindex on;` 才能走目录扫描；`types { }` 补音频 MIME

### 8. 交付

用 `present_files` 打开 `index.html` 让用户直接看到效果，并说明：启动方式、目录约定、部署注意点、已知限制（浏览器不支持的格式、刷新后需重新授权等）。

## 常见陷阱（每条都真实踩过）

- `[hidden]` 会被 `.class { display: flex }` 覆盖 → 必须有全局 `[hidden] { display: none !important; }`
- DOM 引用表（`const el = {...}`）漏一个元素，初始化整条链就断，页面表现为"完全没反应" → 批量核对"使用但未定义"的引用
- `fetch('manifest.json')` 404 会污染控制台 → 属预期回退，但仍应在 README 说明，避免用户误判
- 目录列表可能带站外/父级链接 → 解析后必须校验 `abs.startsWith(base)`
- `file://` 下 `fetch` 完全不可用 → manifest 与目录扫描必须放在 `location.protocol !== 'file:'` 分支里
- 无时间轴的纯文本歌词/字幕会被当作解析失败 → 解析器返回"无时间轴"状态并降级为可滚动列表，而不是空白
- 文件名里的噪声（如 `周杰伦 - (1785354496)夜曲.mp3`）会被当成标题 → 元信息优先读文件内嵌标签，读不到再退回文件名推断

完整清单见 `references/pitfalls.md`。

## 资源索引

| 资源 | 用途 |
| --- | --- |
| `assets/site-skeleton/` | 可直接复制的项目骨架（布局 + 双主题 + 基础设施） |
| `assets/theme.css` | 双主题变量与基础样式片段，独立取用 |
| `assets/web.config` | IIS 配置模板（目录浏览 + MIME + 默认文档） |
| `scripts/local_server.py` | 支持 Range 的本地静态服务器，自动选端口并开浏览器 |
| `scripts/make_manifest.py` | 通用资源目录扫描 → `manifest.json`（支持配对目录） |
| `scripts/verify_page.js` | 真实浏览器验证：报错、元素数量、交互、截图 |
| `references/theme-system.md` | 双主题实现细节、变量语义、防闪、配色建议 |
| `references/data-discovery.md` | 三源降级、目录列表解析、文件名归一化、失败诊断 |
| `references/deployment.md` | IIS / nginx / GitHub Pages / file:// 完整部署清单 |
| `references/pitfalls.md` | 踩坑与排查手册 |

## 质量门槛

交付前逐条确认：

- [ ] 双击 `index.html` 能打开且不报错（`file://` 下优雅降级到文件选择）
- [ ] 通过本地服务器打开时自动加载数据，无需手动操作
- [ ] 两套主题下所有文字可读，无写死颜色的组件
- [ ] 刷新后主题、收藏、列表状态保持
- [ ] 控制台无应用级报错（预期内的 404 回退除外）
- [ ] 移动端窄屏（375px）布局不溢出，侧栏/面板可收起
- [ ] README 写明目录约定、启动方式、三种部署路径与已知限制
