/* ============================================================
   业务逻辑（骨架示例：把同目录 data/ 里的文件列出来）
   替换为实际业务时，主要改：CONFIG、render、open
   ============================================================ */
(function () {
  'use strict';

  const SW = window.SW;

  const CONFIG = {
    dirs: ['data'],          // 要扫描的目录（相对站点根）
    exts: [],                // 扩展名白名单，留空 = 全部；例：SW.EXT.image
    manifest: 'manifest.json',
    title: '资源列表'
  };

  const el = {
    searchInput: document.getElementById('searchInput'),
    btnRescan: document.getElementById('btnRescan'),
    btnTheme: document.getElementById('btnTheme'),
    listTitle: document.getElementById('listTitle'),
    listDesc: document.getElementById('listDesc'),
    list: document.getElementById('list'),
    emptyState: document.getElementById('emptyState'),
    emptyReason: document.getElementById('emptyReason'),
    statusDot: document.getElementById('statusDot'),
    statusText: document.getElementById('statusText')
  };

  const state = {
    files: [],
    keyword: '',
    source: null,
    loading: false
  };

  /* ---------------- 工具 ---------------- */

  function setStatus(text, kind) {
    el.statusText.textContent = text;
    el.statusDot.className = 'dot' + (kind ? ' ' + kind : '');
  }

  function iconOf(ext) {
    if (SW.EXT.audio.indexOf(ext) >= 0) return '♪';
    if (SW.EXT.image.indexOf(ext) >= 0) return '🖼';
    if (SW.EXT.text.indexOf(ext) >= 0) return '≡';
    return ext.slice(0, 3) || '·';
  }

  /* ---------------- 渲染 ---------------- */

  function visibleFiles() {
    const kw = state.keyword.trim().toLowerCase();
    if (!kw) return state.files;
    return state.files.filter(function (f) {
      return f.name.toLowerCase().indexOf(kw) >= 0 || f.base.toLowerCase().indexOf(kw) >= 0;
    });
  }

  function render() {
    const list = visibleFiles();

    el.listTitle.textContent = CONFIG.title;
    el.listDesc.textContent = state.files.length
      ? visibleFiles().length + ' / ' + state.files.length + ' 项'
        + (state.source === 'manifest' ? ' · 来自清单' : ' · 来自目录扫描')
      : '暂无内容';

    if (!list.length) {
      el.list.innerHTML = '';
      el.list.hidden = true;
      el.emptyState.hidden = false;
      el.emptyReason.innerHTML = state.keyword.trim()
        ? '没有匹配的文件，换个关键词试试。'
        : '把文件放进 <code>' + SW.escapeHtml(CONFIG.dirs[0]) + '</code> 文件夹，然后点右上角重新扫描。';
      return;
    }

    el.emptyState.hidden = true;
    el.list.hidden = false;

    el.list.innerHTML = list.map(function (f, i) {
      return '<div class="row" data-i="' + i + '">'
        + '<div class="row-icon">' + SW.escapeHtml(iconOf(f.ext)) + '</div>'
        + '<div class="row-main">'
        + '<div class="row-name">' + SW.escapeHtml(f.name) + '</div>'
        + '<div class="row-sub">' + SW.escapeHtml(f.base) + '</div>'
        + '</div>'
        + '<div class="row-meta">' + (f.size ? SW.fmtSize(f.size) : f.ext.toUpperCase()) + '</div>'
        + '</div>';
    }).join('');

    // 事件委托，避免逐行绑定
    el.list.onclick = function (e) {
      const row = e.target.closest('.row');
      if (!row) return;
      const item = list[Number(row.dataset.i)];
      if (item) open(item);
    };
  }

  /** 默认行为：新标签页打开文件。替换成播放、预览等 */
  function open(item) {
    window.open(item.url, '_blank', 'noopener');
  }

  /* ---------------- 加载 ---------------- */

  async function load(manual) {
    if (state.loading) return;
    state.loading = true;
    setStatus('正在加载…');

    try {
      const result = await SW.loadAll({
        manifestUrl: CONFIG.manifest,
        dirs: CONFIG.dirs,
        exts: CONFIG.exts
      });
      state.files = result.files;
      state.source = result.source;
      render();

      const label = result.source === 'manifest' ? '已从清单读取' : '已从服务器目录读取';
      setStatus(label + ' ' + result.files.length + ' 项', result.files.length ? 'ready' : '');
      if (manual) console.log('[rescan] ' + result.source + ' ' + result.files.length);
    } catch (err) {
      state.files = [];
      state.source = null;
      render();
      setStatus('加载失败：' + err.message, 'error');

      // 分级诊断，给出可执行的操作
      let tip = '';
      if (err.fileProtocol) {
        tip = '当前是直接双击打开的 <code>file://</code> 页面，浏览器禁止自动读取目录。<br>'
          + '请用本地服务器打开：<code>python tools/local_server.py</code>';
      } else if (err.status === 403) {
        tip = '服务器返回 403：目录浏览未开启。<br>'
          + 'IIS：选中该文件夹 → 目录浏览 → 启用；nginx：<code>autoindex on;</code>';
      } else if (err.status === 404) {
        tip = '目录不存在（404），检查部署目录里是否有 <code>' + SW.escapeHtml(CONFIG.dirs[0]) + '</code>，注意大小写。';
      } else if (err.notListing) {
        tip = '该地址返回的不是目录列表（可能被默认文档接管）。<br>'
          + '改用清单方案：<code>python tools/make_manifest.py</code> 生成 <code>manifest.json</code>。';
      } else {
        tip = '请确认 <code>' + SW.escapeHtml(CONFIG.dirs.join(', ')) + '</code> 目录存在，或用清单方式加载。';
      }
      el.emptyState.hidden = false;
      el.emptyReason.innerHTML = tip;
    } finally {
      state.loading = false;
    }
  }

  /* ---------------- 事件 ---------------- */

  el.btnTheme.addEventListener('click', function () {
    SW.theme.toggle();
    el.btnTheme.title = SW.theme.current === 'dark' ? '切换到白天主题' : '切换到夜间主题';
  });

  el.btnRescan.addEventListener('click', function () { load(true); });

  el.searchInput.addEventListener('input', function () {
    state.keyword = this.value || '';
    render();
  });

  /* ---------------- 启动 ---------------- */

  SW.theme.init('dark');
  el.btnTheme.title = SW.theme.current === 'dark' ? '切换到白天主题' : '切换到夜间主题';
  load(false);
})();
