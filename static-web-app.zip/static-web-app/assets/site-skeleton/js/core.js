/* ============================================================
   静态站点基础设施（可直接复用到新项目）
   ------------------------------------------------------------
   包含：
     SW.store      localStorage 安全读写（带前缀、容错）
     SW.theme      双主题（读档 → 应用 → 切换）
     SW.listWebDirectory()  解析服务器目录列表（IIS/nginx/Apache/Python）
     SW.scanDirs()          递归扫描若干目录
     SW.loadManifest()      读取 manifest.json
     SW.loadAll()           三级降级：manifest → 目录扫描
     SW.* 字符串/大小工具
   ============================================================ */
(function (window, document) {
  'use strict';

  const SW = window.SW || {};

  /* ---------------- 配置 ---------------- */

  SW.PREFIX = 'app';
  SW.THEME_KEY = 'theme';

  SW.EXT = {
    audio: ['mp3', 'flac', 'wav', 'ogg', 'oga', 'm4a', 'aac', 'opus', 'wma', 'aiff', 'aif', 'ape'],
    image: ['jpg', 'jpeg', 'png', 'webp', 'avif', 'gif', 'svg', 'bmp'],
    text: ['lrc', 'txt', 'srt', 'vtt', 'md', 'json', 'csv']
  };

  /* ---------------- 字符串工具 ---------------- */

  SW.extOf = function (name) {
    const i = String(name || '').lastIndexOf('.');
    return i >= 0 ? String(name).slice(i + 1).toLowerCase() : '';
  };

  SW.baseName = function (name) {
    const s = String(name || '').split('/').pop();
    const i = s.lastIndexOf('.');
    return i > 0 ? s.slice(0, i) : s;
  };

  /** 归一化键：忽略大小写、空白、标点，用于跨目录配对同名文件 */
  SW.normKey = function (s) {
    return String(s || '')
      .toLowerCase()
      .replace(/\s+/g, '')
      .replace(/[_\-–—·.,，、'"“”()（）\[\]]/g, '');
  };

  SW.stripTrackNo = function (s) {
    return String(s || '').replace(/^\s*\d{1,3}\s*[.\-_、)]?\s*/, '').trim();
  };

  SW.escapeHtml = function (s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  };

  SW.fmtSize = function (bytes) {
    const n = Number(bytes);
    if (!isFinite(n) || n <= 0) return '';
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    let i = 0;
    let v = n;
    while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
    return (i === 0 ? v : v.toFixed(v < 10 ? 1 : 0)) + ' ' + units[i];
  };

  SW.fmtTime = function (sec) {
    if (!isFinite(sec) || sec < 0) return '0:00';
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return m + ':' + (s < 10 ? '0' + s : s);
  };

  /* ---------------- 本地存储 ---------------- */

  SW.store = {
    key: function (k) { return (SW.PREFIX || 'app') + ':' + k; },
    get: function (k, fallback) {
      try {
        const raw = localStorage.getItem(SW.store.key(k));
        if (raw == null) return fallback;
        return JSON.parse(raw);
      } catch (e) {
        return fallback;
      }
    },
    set: function (k, value) {
      try { localStorage.setItem(SW.store.key(k), JSON.stringify(value)); } catch (e) { /* 隐私模式 */ }
    },
    remove: function (k) {
      try { localStorage.removeItem(SW.store.key(k)); } catch (e) {}
    }
  };

  /* ---------------- 双主题 ---------------- */

  SW.theme = {
    current: 'dark',

    /** 读取已存主题并应用；页面 <head> 里已内联设置过一次，这里只做同步 */
    init: function (defaultTheme) {
      const saved = SW.store.get(SW.THEME_KEY, null);
      let t = saved;
      if (t !== 'dark' && t !== 'light') {
        t = (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches)
          ? 'light' : (defaultTheme || 'dark');
      }
      SW.theme.current = t;
      SW.theme.apply();
      return t;
    },

    apply: function () {
      document.documentElement.setAttribute('data-theme', SW.theme.current);
    },

    toggle: function () {
      SW.theme.current = SW.theme.current === 'dark' ? 'light' : 'dark';
      SW.theme.apply();
      SW.store.set(SW.THEME_KEY, SW.theme.current);
      return SW.theme.current;
    }
  };

  /* ---------------- 服务器目录列表解析 ---------------- */

  /**
   * 读取一个可浏览目录，返回 { files: [{url,name}], dirs: [url], url }
   * 只依赖 a[href]，兼容 IIS / nginx autoindex / Apache FancyIndex / Python http.server
   */
  SW.listWebDirectory = async function (dirUrl) {
    const res = await fetch(dirUrl, { cache: 'no-store' });
    if (!res.ok) {
      const err = new Error('HTTP ' + res.status);
      err.status = res.status;
      throw err;
    }

    const text = await res.text();
    const doc = new DOMParser().parseFromString(text, 'text/html');
    const base = res.url || dirUrl;

    const files = [];
    const dirs = [];
    let isListing = false;

    // 判据 1：页面标题
    if (/index of|directory listing|目录列表|目录浏览/i.test(doc.title || '')) isListing = true;

    doc.querySelectorAll('a[href]').forEach(function (a) {
      const raw = (a.getAttribute('href') || '').trim();
      if (!raw) return;

      // 判据 2：父目录链接
      if (raw === '../' || raw === '..') { isListing = true; return; }
      if (raw.charAt(0) === '?' || raw.charAt(0) === '#') return;

      let abs;
      try {
        abs = new URL(raw, base.charAt(base.length - 1) === '/' ? base : base + '/').href;
      } catch (e) { return; }

      // 过滤父级/站外/绝对跳转
      if (abs === base || abs.indexOf(base) !== 0) return;

      const relPath = abs.slice(base.length);
      if (!relPath) return;

      if (raw.charAt(raw.length - 1) === '/' || relPath.charAt(relPath.length - 1) === '/') {
        dirs.push(abs);
      } else {
        let name = relPath.split('/').pop();
        try { name = decodeURIComponent(name); } catch (e) { /* 保留原样 */ }
        if (name) files.push({ url: abs, name: name });
      }
    });

    // 判据 3：解析出了条目
    if (!isListing && !files.length && !dirs.length) {
      const err = new Error('该地址不是目录列表');
      err.notListing = true;
      throw err;
    }

    return { files: files, dirs: dirs, url: base };
  };

  /* ---------------- 目录递归扫描 ---------------- */

  /**
   * @param {object} opt
   *   root  : 目录基准 URL，如 location.origin + '/'
   *   dirs  : ['music'] / ['images','thumbs']
   *   exts  : ['mp3','lrc']
   *   depth : 递归上限，默认 4
   * @returns {Promise<Array<{url,name,dir,ext}>>}
   */
  SW.scanDirs = async function (opt) {
    const root = opt.root || (location.origin + '/');
    const dirs = opt.dirs || ['data'];
    const exts = (opt.exts || []).map(function (e) { return String(e).toLowerCase(); });
    const maxDepth = typeof opt.depth === 'number' ? opt.depth : 4;

    const out = [];

    async function crawl(entry, dirName, depth) {
      if (!entry) return;
      entry.files.forEach(function (f) {
        const ext = SW.extOf(f.name);
        if (exts.length && exts.indexOf(ext) < 0) return;
        out.push({ url: f.url, name: f.name, dir: dirName, ext: ext });
      });
      if (depth >= maxDepth) return;
      for (const subUrl of entry.dirs) {
        try {
          const sub = await SW.listWebDirectory(subUrl);
          await crawl(sub, dirName, depth + 1);
        } catch (e) { /* 单个子目录失败不影响整体 */ }
      }
    }

    let ok = 0;
    for (const d of dirs) {
      const dirUrl = new URL(d.replace(/^\/+|\/+$/g, '') + '/', root).href;
      try {
        const entry = await SW.listWebDirectory(dirUrl);
        await crawl(entry, d, 0);
        ok++;
      } catch (e) { /* 该目录不可读，继续下一个 */ }
    }

    if (!ok) {
      const err = new Error('没有可读取的目录');
      err.noDir = true;
      throw err;
    }
    return out;
  };

  /* ---------------- manifest ---------------- */

  SW.loadManifest = async function (url) {
    const res = await fetch(url, { cache: 'no-store' });
    if (!res.ok) {
      const err = new Error('HTTP ' + res.status);
      err.status = res.status;
      throw err;
    }
    const data = await res.json();
    const items = (data.items || []).filter(function (it) { return it && it.path; });
    return { generated: data.generated || null, items: items };
  };

  /* ---------------- 三级加载 ---------------- */

  /**
   * 依次尝试 manifest → 目录扫描，返回 { source, files }。
   * source: 'manifest' | 'dirs'
   * files : [{ url, name, base, ext, size?, pair? }]
   * 全失败时抛错，err.status / err.notListing / err.noDir 供上层做诊断文案。
   */
  SW.loadAll = async function (opt) {
    const root = opt.root || (location.origin + '/');
    const manifestUrl = opt.manifestUrl || 'manifest.json';
    const dirs = opt.dirs || ['data'];
    const exts = opt.exts || [];

    if (location.protocol !== 'file:') {
      try {
        const m = await SW.loadManifest(manifestUrl);
        if (m.items.length) {
          return {
            source: 'manifest',
            files: m.items.map(function (it) {
              return {
                url: new URL(it.path, root).href,
                name: it.name || it.path.split('/').pop(),
                base: it.base || SW.baseName(it.name || it.path),
                ext: it.ext || SW.extOf(it.name || it.path),
                size: it.size,
                pair: it.pair ? new URL(it.pair, root).href : null
              };
            })
          };
        }
      } catch (e) { /* 清单不存在属正常，继续降级 */ }
    } else {
      const err = new Error('file:// 环境无法自动扫描');
      err.fileProtocol = true;
      throw err;
    }

    const list = await SW.scanDirs({ root: root, dirs: dirs, exts: exts });
    return {
      source: 'dirs',
      files: list.map(function (f) {
        return {
          url: f.url,
          name: f.name,
          base: SW.baseName(f.name),
          ext: f.ext,
          size: null,
          pair: null,
          dir: f.dir
        };
      })
    };
  };

  window.SW = SW;
})(window, document);
