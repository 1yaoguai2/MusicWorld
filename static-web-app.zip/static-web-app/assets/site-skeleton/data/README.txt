把文件放进这个文件夹，页面会自动列出它们。

- 支持子文件夹（递归最多 4 层）
- 想自动加载，用本地服务器打开：`python tools/local_server.py`
- 部署到 GitHub Pages 或未开目录浏览的服务器时，先执行：
  `python tools/make_manifest.py --dir data --pair ""`
