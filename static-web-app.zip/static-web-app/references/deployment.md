# 部署清单

产物是纯静态文件，同一份代码可以部署到任意静态托管。差别只在"能不能列目录"和"MIME 是否正确"。

## 1. IIS

### 1.1 需要的能力

| 需求 | 角色功能 / 配置 |
| --- | --- |
| 目录自动扫描 | 安装"目录浏览"（IIS → 目录浏览），并在 `web.config` 打开 `directoryBrowse` |
| 冷门音频格式可播放 | `web.config` 补 `flac / ogg / opus / aac / aiff / ape` 的 MIME |
| 默认打开 index.html | `defaultDocument` |

`assets/web.config` 是可直接使用的模板，放到站点根目录即可。

### 1.2 500.19 错误

`web.config` 里的 `<directoryBrowse>` 属于需要安装角色功能的节。若服务器没装"目录浏览"，整个节被锁 → 请求返回 **500.19**，站点完全打不开。

处理顺序：

1. 服务器管理器 → 添加角色和功能 → Web 服务器(IIS) → Web 服务器 → 性能和功能 → 勾选「目录浏览」
2. 无权限安装时：**删掉 `<system.webServer>` 里的 `<directoryBrowse enabled="true" />` 这一行**，改用 `manifest.json` 方案

README 必须同时写出这两条退路，否则用户会卡在 500.19。

### 1.3 验证

部署后按顺序确认：

```bash
curl -s -o /dev/null -w "%{http_code}\n" http://站点/                      # 200
curl -s -o /dev/null -w "%{http_code}\n" http://站点/music/                # 200 且返回列表
curl -s -r 0-99 -o /dev/null -w "%{http_code}\n" "http://站点/music/a.mp3" # 206
```

第三条返回 206 说明 Range 生效，媒体进度条才能拖动。IIS 默认支持，nginx 也默认支持；自写的 Python 服务器需要手动实现（见 `scripts/local_server.py`）。

### 1.4 MIME 补充

IIS 默认没有这些类型，缺失时表现为"音频加载失败但文件明明在"：

```xml
<mimeMap fileExtension=".flac" mimeType="audio/flac" />
<mimeMap fileExtension=".ogg"  mimeType="audio/ogg" />
<mimeMap fileExtension=".oga"  mimeType="audio/ogg" />
<mimeMap fileExtension=".opus" mimeType="audio/opus" />
<mimeMap fileExtension=".m4a"  mimeType="audio/mp4" />
<mimeMap fileExtension=".aac"  mimeType="audio/aac" />
<mimeMap fileExtension=".aiff" mimeType="audio/aiff" />
<mimeMap fileExtension=".ape"  mimeType="audio/x-ape" />
<mimeMap fileExtension=".lrc"  mimeType="text/plain; charset=utf-8" />
```

## 2. GitHub Pages

### 2.1 必须做

1. **提交 `.nojekyll`**（空文件即可）。否则 Jekyll 会忽略 `_` 开头的文件和目录，`_headers`、`_next` 之类会消失。
2. **提交 `manifest.json`**。Pages **不支持目录列表**，只有清单方案可用。推送前跑一次 `python tools/make_manifest.py`。
3. 路径全部用**相对路径**（`css/style.css`，不是 `/css/style.css`）。仓库名会成为子路径（`user.github.io/repo/`），以 `/` 开头的绝对路径会 404。

### 2.2 常见故障

| 现象 | 原因 |
| --- | --- |
| 页面 404 | Settings → Pages 的 Branch 未选或选错目录 |
| 样式全丢 | 用了绝对路径 `/css/...` |
| 中文文件名 404 | 文件名在提交时被系统改了编码，`git config core.quotepath false` 后重命名 |
| 目录扫描永远失败 | Pages 不提供 autoindex，属预期，只能靠 manifest |
| 更新不生效 | CDN 缓存，等 1–2 分钟或刷新时加 `?v=` |

### 2.3 大小限制

单仓库 1GB、单文件 100MB。音频/视频体积大时用 Git LFS，或在本地生成清单后只提交清单与缩略图。

## 3. nginx

```nginx
server {
    root /var/www/app;
    index index.html;

    location / {
        try_files $uri $uri/ =404;
        autoindex on;          # 目录扫描必需
        autoindex_exact_size off;
        charset utf-8;         # 中文文件名不乱码
    }

    types {
        audio/flac  flac;
        audio/ogg   ogg oga;
        audio/opus  opus;
        audio/mp4   m4a;
    }

    # 媒体拖动必需
    add_header Accept-Ranges bytes;
}
```

`charset utf-8` 缺失会让目录列表里的中文变成 HTML 实体或乱码，页面解析出的文件名就是错的。

## 4. 直接双击打开（file://）

- `fetch` 全部不可用 → 页面必须跳过 manifest 与目录扫描，直接展示文件选择入口
- 音频 `src` 用 `URL.createObjectURL(file)`，不要试图拼 `file://` 路径
- 提示用户：这种模式不会记住资源库，刷新后需重选

推荐在 README 里把"双击打开"和"本地服务器"的差异写成一张表，比一句"建议用 Chrome"有用得多。

## 5. 发布前检查表

- [ ] `index.html`、`css/`、`js/` 能被访问（无大小写不一致）
- [ ] 有 `manifest.json`（Pages / 未开目录浏览的 IIS）
- [ ] `web.config` 已放根目录，且服务器装过"目录浏览"或已删该节
- [ ] `.nojekyll` 已提交（GitHub Pages）
- [ ] 相对路径，无 `http://localhost` 残留、无绝对盘符路径
- [ ] 移动端用真机或 375px 视口过一遍
- [ ] README 写明三种部署路径与已知限制
