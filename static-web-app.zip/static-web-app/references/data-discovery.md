# 数据自动发现：三源降级

## 1. 为什么需要三级

静态页面没有后端，想"打开就自动看到资源"有四种环境，能力完全不同：

| 环境 | fetch | 目录列表 | 文件选择 | 结论 |
| --- | --- | --- | --- | --- |
| IIS（开目录浏览） | ✅ | ✅ | ✅ | 走目录扫描 |
| nginx（`autoindex on`） | ✅ | ✅ | ✅ | 走目录扫描 |
| GitHub Pages / 任意静态托管 | ✅ | ❌ | ✅ | **必须**用 manifest |
| 双击 `file://` 打开 | ❌ | ❌ | ✅ | 只能选文件 |

所以固定三级顺序，任一级成功即停：

```
manifest.json  →  目录列表扫描  →  用户选择（目录授权 / 目录选择 / 多选文件）
```

## 2. 第一级：manifest.json

服务端（或发布前）生成静态清单，最确定、最快、不依赖服务器配置。

```json
{
  "generated": "2026-10-21T15:02:11",
  "count": 2,
  "items": [
    { "path": "music/a.mp3", "name": "a.mp3", "base": "a", "ext": "mp3", "size": 5210342, "pair": "lyrics/a.lrc" },
    { "path": "music/b.flac", "name": "b.flac", "base": "b", "ext": "flac", "size": 31200331 }
  ]
}
```

加载要点：

- `fetch(url, { cache: 'no-store' })`，避免用户换了文件还读旧清单
- 字段全部做存在性校验，缺 `path` 的条目直接丢弃
- 清单为空数组时**不算成功**，继续降级（空清单往往是生成脚本没跑）
- 404 属正常回退路径，不要弹错误提示打扰用户

## 3. 第二级：目录列表扫描

### 3.1 只认 `a[href]`

不同服务器输出的 HTML 结构差异极大（IIS 是 `<pre>` + `<a>`，nginx 是表格，Apache 是表格 + 图标，Python 是 `<ul>`），唯一稳定的共同点是**目录里每个条目都是一个 `<a href>`**。所以解析只做：取所有 `a[href]`，`new URL(href, base)` 转绝对地址，按结尾 `/` 分文件与子目录。

### 3.2 判定"这是不是目录列表"

不要用 `../` 链接作唯一判据——Python `http.server` 的列表就没有父目录链接，早期版本因此把正常目录判成"不是列表"。

正确判据（满足任一即可）：

1. 页面标题匹配 `/index of|directory listing|目录列表|目录浏览/i`
2. 存在 `href="../"` 或 `href=".."`
3. **解析出了至少一个条目**（文件或子目录）

只有三条都不满足才抛 `notListing`。

### 3.3 必须做的过滤

```js
const abs = new URL(raw, base.endsWith('/') ? base : base + '/').href;
if (abs === base || abs.indexOf(base) !== 0) return;  // 父级链接、站外链接、绝对路径跳到别处
if (raw.startsWith('?') || raw.startsWith('#')) return; // 排序参数、锚点
```

不做 `indexOf(base) === 0` 校验，会把 `../` 解析出的父目录当成子目录，递归时越走越远。

### 3.4 中文与编码

```js
let name = rel.split('/').pop();
try { name = decodeURIComponent(name); } catch (e) {}
```

`decodeURIComponent` 遇到不合法的 `%` 序列会抛错（老服务器输出 `%E4` 截断就可能出现），必须兜底保留原样。

### 3.5 递归

- 深度上限 4 层（`music/专辑/CD1/` 已足够，再深说明组织方式异常）
- 子目录 `fetch` 失败静默 `continue`，一个坏目录不能让整轮扫描失败
- 并发不要放开，串行 `await` 在几十个目录时也足够快，且不会打爆服务器

### 3.6 分类与配对

按扩展名分流到各自的桶（音频/图片/文本），再按归一化键把"配对文件"挂到主文件上：

```js
function normKey(s) {
  return s.toLowerCase()
    .replace(/\s+/g, '')
    .replace(/[_\-–—·.,，、'"“”()（）\[\]]/g, '');
}
function stripTrackNo(s) {
  return s.replace(/^\s*\d{1,3}\s*[.\-_、)]?\s*/, '').trim();
}
```

两个键都建索引（原始名、去序号名），命中任一即可，能覆盖 `01. 歌名.mp3` ↔ `歌名.lrc`。

## 4. 第三级：用户选择

三级降级，能力从强到弱：

1. `window.showDirectoryPicker()`（Chrome/Edge）：可持久化 handle 到 IndexedDB，下次一键恢复
2. `<input type="file" webkitdirectory>`：几乎所有浏览器，能保留相对路径（`file.webkitRelativePath`），从而区分音乐目录与歌词目录
3. `<input type="file" multiple>`：最后兜底，用户手动多选

关键实现点：

- 只在 `location.protocol === 'file:'` 或前两级失败时才展示选择入口，别让正常环境看到"点这里导入"
- `webkitdirectory` 的 input 只能通过用户手势触发 `.click()`，且 `value` 要在每次 `change` 后清空，否则同一目录选第二次不触发
- 从 `FileList` 建库时用 `webkitRelativePath` 判断文件属于哪个逻辑目录

## 5. 失败诊断（直接给操作步骤）

空状态页要能回答"为什么没有数据"，按错误码给不同文案：

| 现象 | 原因 | 给用户的指引 |
| --- | --- | --- |
| 403 | 目录浏览关闭 | IIS：选中 `music` 文件夹 → 目录浏览 → 启用；nginx：`autoindex on;` |
| 404 | 目录不存在 | 确认部署目录里有 `music/`，注意大小写 |
| 返回 HTML 但不是列表 | 默认文档/SPA fallback 接管了 | 改用 `manifest.json`（最省事） |
| 目录为空 | 真的没文件 | 提示把文件放进 `music/` 后点"重新扫描" |
| `file://` | 浏览器禁止 fetch | 提示用 `start.bat`/本地服务器打开 |

文案要带**具体菜单路径**，不要写"请检查服务器配置"。

## 6. 刷新后自动重载

- manifest / 目录扫描：每次 `load` 直接重跑，无需用户操作
- 目录授权（handle）：`queryPermission` → `granted` 直接恢复；`prompt` 时显示"恢复上次的*库名称*"按钮（必须在用户手势里 `requestPermission`）
- 文件选择：受安全限制无法持久化，刷新后需重选，README 里写明
