# 双主题实现规范

## 1. 结构

```
样式层：:root（尺寸/字体/圆角/缓动） → html[data-theme="dark"]（颜色） → html[data-theme="light"]（颜色）
状态层：document.documentElement.dataset.theme = 'dark' | 'light'
持久层：localStorage['<项目前缀>:theme']
```

三处必须同时存在，缺一不可：变量定义、属性切换、持久化。

## 2. 防闪白（关键）

主题必须在**首次绘制前**决定。做法：在 `<head>` 内、样式表之前放一段内联脚本，直接写 `data-theme`。

```html
<script>
  (function () {
    var t = null;
    try { t = localStorage.getItem('app:theme'); } catch (e) {}
    if (t !== 'dark' && t !== 'light') {
      t = window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
    }
    document.documentElement.setAttribute('data-theme', t);
  })();
</script>
```

要点：

- 必须内联，不能放在外部 JS 里（外部脚本是异步到达的，会晚于首次绘制）
- `localStorage` 在隐私模式/沙箱里可能抛异常，必须 `try/catch`
- 无存储值时跟随系统 `prefers-color-scheme`，有存储值时以存储为准

同时补：

```html
<meta name="color-scheme" content="dark light">
<html lang="zh-CN" data-theme="dark">
```

`color-scheme` 让滚动条、`<input>`、`<select>` 的原生外观跟随主题，否则浅色主题下会出现黑底输入框。

## 3. 变量语义

统一命名，新项目直接沿用，避免每个项目重新发明：

| 变量 | 含义 |
| --- | --- |
| `--bg` | 页面底色 |
| `--panel` | 卡片/面板背景（深色用半透明白，浅色用半透明白+模糊） |
| `--panel-solid` | 不透明面板（弹层、抽屉，避免叠透） |
| `--panel-hover` | 悬停态背景 |
| `--border` / `--border-strong` | 描边 / 强调描边 |
| `--text` / `--text-dim` / `--text-faint` | 主文字 / 次要 / 弱化 |
| `--shadow` | 大阴影 |
| `--bar-bg` | 吸底栏背景（常带 `backdrop-filter`） |
| `--input-bg` | 输入框背景 |
| `--accent` / `--accent-2` / `--accent-soft` | 主色 / 辅色 / 主色淡背景，两主题共用 |

深色不适合纯黑：用 `#07080d` 这类近黑，配 3.5% 白透明面板，层次才出得来。浅色不用纯白：`#eef1f8` 配 72% 白面板。

## 4. 组件写法

组件内**只允许**出现 `var(--x)`，不写任何十六进制或 `rgba()` 字面色值：

```css
.card { background: var(--panel); border: 1px solid var(--border); color: var(--text); }
```

例外只有两个：品牌色渐变允许表达为 `linear-gradient(140deg, var(--accent), var(--accent-2))`；需要按主题走不同渐变的（如封面占位），把整条渐变放进主题变量（`--cover-1` / `--cover-2`）。

## 5. 切换按钮

```html
<button class="icon-btn" id="btnTheme" title="切换白天 / 夜间主题">
  <svg class="ico-moon">…</svg>   <!-- 深色时显示月亮 -->
  <svg class="ico-sun">…</svg>    <!-- 浅色时显示太阳 -->
</button>
```

```css
html[data-theme="dark"] .ico-sun { display: none; }
html[data-theme="light"] .ico-moon { display: none; }
```

```js
function applyTheme() {
  document.documentElement.dataset.theme = state.theme;
  btnTheme.title = state.theme === 'dark' ? '切换到白天主题' : '切换到夜间主题';
}
function toggleTheme() {
  state.theme = state.theme === 'dark' ? 'light' : 'dark';
  applyTheme();
  store.set('theme', state.theme);
}
```

按钮 `title` 要跟着状态变，否则用户不确定点了会发生什么。

## 6. 过渡

给 `background-color` 与 `color` 加 `.3s` 过渡，切换时有呼吸感；**不要**对 `background-image`（径向渐变）加过渡，浏览器无法插值，会闪烁。

```css
body { transition: background-color .35s var(--ease), color .35s var(--ease); }
```

## 7. 自检

切换后逐项扫一遍：

1. 所有正文、次要文字、占位符文字对比度是否够（浅色下 `--text-faint` 最容易糊）
2. 边框是否还看得见（浅色下 `rgba(255,255,255,.075)` 会完全消失——浅色必须用深色描边）
3. 阴影是否过重（浅色用 `rgba(24,38,78,.13)`，不要沿用深色的 `rgba(0,0,0,.6)`）
4. 滚动条、`::selection`、输入框光标是否跟随
5. 半透明面板叠加在渐变背景上是否出现脏色
