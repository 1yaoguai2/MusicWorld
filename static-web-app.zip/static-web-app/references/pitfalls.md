# 踩坑与排查手册

按"症状 → 原因 → 修法"组织。遇到无法解释的空白页、无响应、加载不到数据，先在这里搜症状。

## A. 页面完全没反应

### A1. 初始化中断，任何按钮都无效

**症状**：页面渲染出静态 HTML，但所有交互失效，控制台第一条报错是 `Cannot read properties of null (reading 'addEventListener')` 或 `... of undefined`。
**原因**：`const el = { ... }` DOM 引用表漏了某个元素，`$('#id')` 返回 `null`，后续 `el.xxx.addEventListener` 直接抛错，整段初始化脚本终止。
**修法**：

```bash
# 使用但未定义的引用
grep -oE "el\.[a-zA-Z]+" js/app.js | sort -u | sed 's/el\.//' > used.txt
sed -n '/const el = {/,/};/p' js/app.js | grep -oE "^\s+[a-zA-Z]+:" | sed 's/[ :]*//g' | sort -u > defined.txt
comm -23 used.txt defined.txt
```

在 `el` 表里补上缺失项即可。更稳的做法：初始化末尾加一段自检，把 `null` 的键打印到控制台，而不是让它静默炸掉。

### A2. 脚本报错但控制台被清空

**症状**：页面空白，`console` 无输出。
**原因**：脚本在 `DOMContentLoaded` 之前执行，`document.querySelector` 返回 `null`；或脚本标签放在 `</body>` 之后被 HTML 错误截断。
**修法**：脚本置于 `</body>` 前；或整体包进 `document.addEventListener('DOMContentLoaded', init)`。

## B. 元素显隐异常

### B1. `hidden` 属性无效，本应隐藏的层一直显示

**症状**：空状态与列表同时出现，弹层始终挂在页面上。
**原因**：`.list-view { display: flex }` 这类类选择器的优先级高于 `[hidden]` 的 UA 默认样式（`display: none` 来自浏览器默认表，会被作者样式覆盖）。
**修法**：全局补一条

```css
[hidden] { display: none !important; }
```

### B2. 弹层关闭后遮罩不消失

**症状**：关闭面板后页面仍然点不动。
**原因**：多个浮层（侧栏、面板、抽屉）共用一个遮罩，各处独立开关时互相覆盖状态。
**修法**：把"是否显示遮罩"收敛到单一函数 `syncOverlay()`，每次开关后调用它统一判断所有浮层是否都已关闭。不要在每个 close 函数里各自写条件。

## C. 数据加载不到

### C1. 服务器上明明有文件，页面还是空

按顺序排查：

1. `curl http://站点/music/` → 403 说明目录浏览未开；404 说明目录名/大小写不对
2. 返回了 HTML 但不是列表 → 被默认文档或 SPA fallback 接管，改用 `manifest.json`
3. 控制台有 CORS 报错 → 目录和页面不同源（少见），改同源部署

### C2. 目录列表被判为"不是目录列表"

**症状**：`curl` 能看到完整列表，但页面报 `notListing`。
**原因**：早期判据要求存在 `../` 父目录链接，而 Python `http.server` 的列表**没有**父链接。
**修法**：判据改为"标题含 Index of / 有 `../` / **解析出了至少一个条目**"，三者满足其一即可（见 `references/data-discovery.md` 3.2）。

### C3. 递归扫到了站点外的目录

**症状**：扫描时间异常长，条目数远超预期。
**原因**：`../` 或 `/other/` 这类链接被解析成绝对地址后纳入递归。
**修法**：解析后强制 `abs.indexOf(base) === 0`，并且 `abs !== base`。

### C4. 扫描卡住/超时

**原因**：对每个子目录 `await` 且无深度限制，遇到循环符号链接会无限递归。
**修法**：深度上限 4；子目录失败 `continue`；串行请求保持服务器压力可控。

### C5. 中文文件名变成 `%E5%A4%9C` 或乱码

**原因**：未解码 URL，或服务器响应头 `charset` 不是 UTF-8（nginx 常见）。
**修法**：`decodeURIComponent(name)` 加 `try/catch`；nginx 加 `charset utf-8;`；Python 服务器不要用 GBK 写列表。

### C6. 刷新后 manifest 读的是旧内容

**原因**：HTTP 缓存。
**修法**：`fetch(url, { cache: 'no-store' })`；本地服务器统一加 `Cache-Control: no-store`。

### C7. 回退链永远只走第一级

**症状**：`manifest.json` 不存在，但页面不继续尝试目录扫描。
**原因**：判断函数没有显式 `return true/false`，调用方拿到 `undefined`，按"成功"处理。
**修法**：每个 `tryXxx()` 在成功分支 `return true`、失败分支 `return false`，调用方只认布尔值。这类 bug 不会报错，只会让降级链静默失效。

### C8. `file://` 打开时一片空白且 fetch 报错

**原因**：`file://` 下 `fetch` 被 CORS 策略完全禁止。
**修法**：`if (location.protocol !== 'file:')` 才走 manifest / 目录扫描，否则直接展示文件选择入口。

## D. 媒体播放

### D1. 进度条拖不动

**症状**：点击进度条跳转无效，点击后回到开头。
**原因**：服务器不支持 Range 请求，返回 200 全量内容而非 206。
**修法**：用支持 Range 的服务器（`scripts/local_server.py`）；IIS/nginx 原生支持；确认响应头有 `Accept-Ranges: bytes`。

### D2. 换了首歌服务端刷一堆 ConnectionResetError

**原因**：浏览器切换 `src` 会主动断开上一个连接，服务端 `send_head` 写入时抛异常。
**修法**：服务端 `handle_error` 里忽略 `ConnectionResetError`；或 `log_message` 静默，避免日志刷屏。

### D3. 某些格式点了没声音

**原因**：浏览器解码能力有限，`.ape`、`.wma`、部分 `.m4a`（ALAC）普遍不支持。
**修法**：README 里明确列出支持范围（mp3 / flac / wav / ogg / m4a-AAC / aac），提示用户转码，不要试图用 JS 解码。

### D4. 切歌后封面/标题还停留在上一首

**原因**：异步加载竞态——旧请求晚于新请求返回，把新状态覆盖了。
**修法**：每次加载递增 `loadSeq`，异步回调里比对 `seq !== loadSeq` 直接 `return`。

### D5. 同名匹配失败

**症状**：`01. 歌名.mp3` 找不到 `歌名.lrc`。
**修法**：归一化键匹配（去空白、标点、开头序号），两个键都建索引（原始名 + 去序号名）。见 `references/data-discovery.md` 3.6。

### D6. 纯文本歌词/字幕显示为空白

**症状**：歌词文件存在，但页面提示"歌词为空"。
**原因**：解析器只认 LRC 的 `[mm:ss.xx]` 标签，纯文本行被全部丢弃。
**修法**：解析结果加 `plain: true` 标记，无时间轴时按普通段落渲染（可手动滚动），并禁用自动高亮与点击跳转。

### D7. 标题里带着一堆数字

**症状**：标题显示 `(1785354496)夜曲`。
**原因**：直接用了文件名，而文件名带下载站点加的时间戳。
**修法**：优先读文件内嵌元信息（ID3v2 的 `TIT2`/`TPE1`），读不到再用文件名推断；推断时剔除 `(数字)`、`[数字]` 段。

## E. 主题

### E1. 浅色主题下部分区域仍是黑的

**原因**：该组件写死了 `#0e1119`、`rgba(255,255,255,.05)` 之类的字面色。
**修法**：`grep -nE "#[0-9a-fA-F]{3,8}|rgba?\(" css/style.css`，逐个替换为变量；需要特殊值的提到主题块里定义新变量。

### E2. 浅色下边框消失 / 阴影过重

**原因**：深浅主题沿用了同一套描边与阴影（深色用白色半透明描边，浅色必须换深色描边）。
**修法**：`--border`、`--border-strong`、`--shadow` 两套主题各写一份，不要共用。

### E3. 刷新瞬间黑底一闪

**原因**：主题在外部 JS 里设置，晚于首次绘制。
**修法**：`<head>` 内联设置 `data-theme` 的脚本，见 `references/theme-system.md` 第 2 节。

### E4. 切换主题时背景闪一下

**原因**：给 `background-image`（径向渐变）加了 transition，浏览器无法插值。
**修法**：只给 `background-color` 和 `color` 加过渡。

## F. 持久化

### F1. 白屏 + `Unexpected token` 报错

**原因**：`JSON.parse(localStorage.getItem(...))` 读到半截或旧格式数据。
**修法**：统一封装 `store.get(key, fallback)`，内部 `try/catch` + 类型校验 + 字段级回退默认值。

### F2. 无痕模式下整个应用挂掉

**原因**：`localStorage` 在隐私模式/沙箱 iframe 里访问即抛异常。
**修法**：所有读写包在 `try/catch` 里，失败时降级为内存变量，功能可用但不持久。

## G. 测试与调试

### G1. Edge `--headless --dump-dom` 输出为空

**原因**：部分版本的 headless 与 `--virtual-time-budget` 组合返回空 stdout，`--screenshot` 却正常。
**修法**：改用 `playwright-core` 驱动系统浏览器：

```bash
NODE_PATH=<node-workspace>/node_modules node scripts/verify_page.js --url http://127.0.0.1:8000/
```

`chromium.launch({ channel: 'msedge' })` 直接用已安装的 Edge，无需下载 ~150MB 浏览器。

### G2. `setInputFiles` 对 `webkitdirectory` 无效

**原因**：这类 input 期望的是**目录路径**，不是文件列表。
**修法**：传目录（`page.setInputFiles('#inputDir', 'C:/tmp/sample-dir')`），或改用多选 input 测试文件导入路径。

### G3. 控制台总有 404

**原因**：通常是 `manifest.json` 不存在时的正常回退。
**修法**：无需修复，但要在 README 说明，避免用户以为页面坏了；也可在开发时先生成一次清单。

## H. 浏览器能力差异

### H1. 「选择文件夹」按钮在某些浏览器点击无效

**原因**：`window.showDirectoryPicker` 只有 Chromium 系支持；Firefox/Safari 直接没有该 API。
**修法**：能力检测 `typeof window.showDirectoryPicker === 'function'`，不支持时降级到 `<input webkitdirectory>`；再不行提示用本地服务器打开。

### H2. 内嵌预览（iframe）里点选择按钮没反应

**原因**：跨源 iframe 缺少 `allow` 权限，文件选择器被静默拦截。
**修法**：提示用户在独立标签页/本地服务器中打开；或把入口指向服务器扫描而不是文件选择。

### H3. 移动端长按/滚动穿透

**原因**：弹层打开时未锁定 body 滚动。
**修法**：打开时 `document.body.style.overflow = 'hidden'`，关闭时还原。

## I. 交付前自问

1. 双击 `index.html` 试过了吗？（不是只用服务器试）
2. 两套主题都逐屏看过了吗？
3. 刷新一次，状态还在吗？
4. 375px 宽下会不会横向溢出？
5. 控制台每一条报错都能解释吗？
6. README 里的部署步骤，换台机器照着做能成功吗？
