#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
扫描资源目录，生成 manifest.json（静态站点自动加载数据的首选方案）。

用法示例：
    # 默认：扫描 ./music，配对 ./lyrics，输出 ./manifest.json
    python tools/make_manifest.py

    # 相册站点：扫描 images，按图片扩展名过滤
    python tools/make_manifest.py --dir images --pair "" --ext jpg,jpeg,png,webp,avif,gif

    # 多目录
    python tools/make_manifest.py --dir music --dir sfx --pair lyrics

输出结构：
    {
      "generated": "2026-10-21T15:20:00",
      "count": 2,
      "items": [
        {"path": "music/a.mp3", "name": "a.mp3", "base": "a", "ext": "mp3",
         "size": 5210342, "pair": "lyrics/a.lrc"}
      ]
    }

说明：
  * 路径统一用正斜杠、相对 root，直接可以拼在页面 URL 后面
  * pair 通过归一化文件名匹配（忽略大小写、空白、标点、开头序号）
  * GitHub Pages / 未开目录浏览的 IIS 必须提交本文件
"""

import argparse
import json
import os
import re
from datetime import datetime

AUDIO_EXT = {"mp3", "flac", "wav", "ogg", "oga", "m4a", "aac", "opus",
             "wma", "aiff", "aif", "ape", "mp4"}
TEXT_EXT = {"lrc", "txt", "srt", "vtt", "md"}
DEFAULT_EXT = AUDIO_EXT | TEXT_EXT


def natural_key(text):
    return [int(part) if part.isdigit() else part.lower()
            for part in re.split(r"(\d+)", text)]


def norm_key(text):
    text = text.lower()
    text = re.sub(r"\s+", "", text)
    return re.sub(r"[_\-–—·.,，、'\"“”()（）\[\]]", "", text)


def strip_track_no(text):
    return re.sub(r"^\s*\d{1,3}\s*[.\-_、)]?\s*", "", text).strip()


def walk_files(root, exts):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = sorted([d for d in dirnames if not d.startswith(".")])
        for name in sorted(filenames, key=natural_key):
            if name.startswith("."):
                continue
            if os.path.splitext(name)[1].lower().lstrip(".") in exts:
                yield os.path.join(dirpath, name)


def rel(path, root):
    return os.path.relpath(path, root).replace("\\", "/")


def guess_title(base):
    """文件名 → 标题（去掉开头序号与下载站加的数字段）"""
    s = strip_track_no(base)
    s = re.sub(r"[(\[（【]\s*\d{6,}\s*[)\]）】]", "", s).strip()
    return s or base


def main():
    parser = argparse.ArgumentParser(description="扫描资源目录生成 manifest.json")
    parser.add_argument("--root", default=".", help="站点根目录（默认当前目录）")
    parser.add_argument("--dir", action="append", help="要扫描的目录，可重复，默认 music")
    parser.add_argument("--pair", default="lyrics", help="用于配对的文件目录（如 lyrics），留空则不配对")
    parser.add_argument("--ext", default="", help="逗号分隔的扩展名白名单，留空用内置音频+文本集合")
    parser.add_argument("--out", default="manifest.json", help="输出文件名（相对 root）")
    args = parser.parse_args()

    root = os.path.abspath(args.root)
    dirs = args.dir or ["music"]
    exts = ({e.strip().lower().lstrip(".") for e in args.ext.split(",") if e.strip()}
            or DEFAULT_EXT)

    # 配对索引
    pair_index = {}
    pair_dir_name = args.pair.strip()
    if pair_dir_name:
        pair_path = os.path.join(root, pair_dir_name)
        if os.path.isdir(pair_path):
            for path in walk_files(pair_path, TEXT_EXT | exts):
                base = os.path.splitext(os.path.basename(path))[0]
                pair_index.setdefault(norm_key(base), path)
                pair_index.setdefault(norm_key(strip_track_no(base)), path)

    items = []
    for d in dirs:
        target = os.path.join(root, d)
        if not os.path.isdir(target):
            print("[!] 跳过不存在的目录：%s" % d)
            continue
        for path in walk_files(target, exts):
            base = os.path.splitext(os.path.basename(path))[0]
            item = {
                "path": rel(path, root),
                "name": os.path.basename(path),
                "base": base,
                "ext": os.path.splitext(path)[1].lower().lstrip("."),
                "size": os.path.getsize(path),
                "title": guess_title(base),
            }
            if pair_index:
                hit = (pair_index.get(norm_key(base))
                       or pair_index.get(norm_key(strip_track_no(base))))
                if hit:
                    item["pair"] = rel(hit, root)
            items.append(item)

    items.sort(key=lambda x: natural_key(x["path"]))

    data = {
        "generated": datetime.now().isoformat(timespec="seconds"),
        "count": len(items),
        "items": items,
    }

    out_path = os.path.join(root, args.out)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    paired = sum(1 for i in items if i.get("pair"))
    print("[+] 已生成 %s" % args.out)
    print("    条目 %d 个，配对成功 %d 个" % (len(items), paired))
    if items and pair_index and paired == 0:
        print("    提示：配对文件需与主文件同名（扩展名不同），放在 %s/ 里" % pair_dir_name)
    if not items:
        print("    提示：%s 里没有符合扩展名的文件，检查 --dir 与 --ext" % ",".join(dirs))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
