#!/usr/bin/env node
/**
 * 静态页面真实浏览器验证脚本（playwright-core + 系统已装浏览器，无需下载）。
 *
 * 用法：
 *   NODE_PATH=<node-workspace>/node_modules node scripts/verify_page.js \
 *     --url http://127.0.0.1:8000/ \
 *     --expect "#trackList .track-row" \
 *     --click "#trackList .track-row" \
 *     --eval "document.querySelector('#nowTitle').textContent" \
 *     --shot ./check.png
 *
 * 参数：
 *   --url <url>            必填，页面地址
 *   --expect <selector>    断言选择器数量 > 0，可重复
 *   --absent <selector>    断言选择器数量 == 0，可重复
 *   --click <selector>     点击第一个匹配元素
 *   --wait <ms>            首次加载后等待时间，默认 1500
 *   --eval <expr>          在页面执行表达式并输出结果（可重复）
 *   --shot <path>          截图路径
 *   --width / --height     视口尺寸，默认 1600x960
 *   --channel <name>       浏览器通道，默认 msedge，失败自动回退 chrome
 *
 * 退出码：0 全部通过；1 有断言失败或页面级报错。
 */

const fs = require('fs');
const path = require('path');

let chromium;
try {
  ({ chromium } = require('playwright-core'));
} catch (e) {
  console.error('[x] 缺少 playwright-core。请安装：');
  console.error('    cd <node-workspace> && npm install playwright-core');
  console.error('    运行前设置 NODE_PATH=<node-workspace>/node_modules');
  process.exit(2);
}

function parseArgs(argv) {
  const out = { expect: [], absent: [], eval: [], wait: 1500, width: 1600, height: 960, channel: 'msedge' };
  for (let i = 2; i < argv.length; i++) {
    const key = argv[i];
    const val = argv[i + 1];
    switch (key) {
      case '--url': out.url = val; i++; break;
      case '--expect': out.expect.push(val); i++; break;
      case '--absent': out.absent.push(val); i++; break;
      case '--click': out.click = val; i++; break;
      case '--eval': out.eval.push(val); i++; break;
      case '--shot': out.shot = val; i++; break;
      case '--wait': out.wait = parseInt(val, 10) || 1500; i++; break;
      case '--width': out.width = parseInt(val, 10) || 1600; i++; break;
      case '--height': out.height = parseInt(val, 10) || 960; i++; break;
      case '--channel': out.channel = val; i++; break;
      default: break;
    }
  }
  return out;
}

async function launch(channel) {
  const opts = { headless: true, args: ['--disable-gpu', '--no-first-run'] };
  try {
    return await chromium.launch(Object.assign({ channel }, opts));
  } catch (e) {
    if (channel !== 'chrome') {
      console.log('[!] ' + channel + ' 启动失败，回退 chrome');
      return chromium.launch(Object.assign({ channel: 'chrome' }, opts));
    }
    throw e;
  }
}

(async () => {
  const args = parseArgs(process.argv);
  if (!args.url) {
    console.error('[x] 缺少 --url');
    process.exit(2);
  }

  const browser = await launch(args.channel);
  const page = await browser.newPage({ viewport: { width: args.width, height: args.height } });

  const consoleErrors = [];
  const pageErrors = [];
  const httpErrors = [];

  page.on('console', m => { if (m.type() === 'error') consoleErrors.push(m.text()); });
  page.on('pageerror', e => pageErrors.push(e.message));
  page.on('response', r => { if (r.status() >= 400) httpErrors.push(r.status() + ' ' + r.url()); });

  const report = { url: args.url, asserts: [], evals: [], shot: null, failed: false };

  await page.goto(args.url, { waitUntil: 'load', timeout: 30000 });
  await page.waitForTimeout(args.wait);

  for (const sel of args.expect) {
    const n = await page.locator(sel).count();
    report.asserts.push({ type: 'expect', selector: sel, count: n, pass: n > 0 });
    if (n === 0) report.failed = true;
  }
  for (const sel of args.absent) {
    const n = await page.locator(sel).count();
    report.asserts.push({ type: 'absent', selector: sel, count: n, pass: n === 0 });
    if (n > 0) report.failed = true;
  }

  if (args.click) {
    try {
      await page.locator(args.click).first().click({ timeout: 8000 });
      await page.waitForTimeout(1200);
      report.asserts.push({ type: 'click', selector: args.click, pass: true });
    } catch (e) {
      report.asserts.push({ type: 'click', selector: args.click, pass: false, error: e.message.split('\n')[0] });
      report.failed = true;
    }
  }

  for (const expr of args.eval) {
    try {
      const value = await page.evaluate(expr);
      report.evals.push({ expr, value });
    } catch (e) {
      report.evals.push({ expr, error: e.message.split('\n')[0] });
    }
  }

  if (args.shot) {
    const abs = path.resolve(args.shot);
    fs.mkdirSync(path.dirname(abs), { recursive: true });
    await page.screenshot({ path: abs, fullPage: false });
    report.shot = abs;
  }

  report.consoleErrors = consoleErrors;
  report.pageErrors = pageErrors;
  report.httpErrors = httpErrors;
  if (pageErrors.length) report.failed = true;

  console.log(JSON.stringify(report, null, 2));

  await browser.close();
  process.exit(report.failed ? 1 : 0);
})().catch(err => {
  console.error('[x] 执行失败：' + err.message);
  process.exit(2);
});
